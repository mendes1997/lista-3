let contadora = 1

while (contadora<11) {
    console.log("O número exibido é : " + contadora)
    contadora++
}