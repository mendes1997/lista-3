let contadora = 1
let acumuladora = 0

while (contadora<101) {
    acumuladora = acumuladora+contadora
    contadora++
}

 console.log("A soma dos números de 1 até 100 é : " + contadora)