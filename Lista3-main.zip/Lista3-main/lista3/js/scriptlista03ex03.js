let contadora = 1
let acumuladora = 0

while (contadora<51) {
    if (contadora %2 == 0){
        console.log("O número " + contadora + " é par.")

    }
    contadora++
}
